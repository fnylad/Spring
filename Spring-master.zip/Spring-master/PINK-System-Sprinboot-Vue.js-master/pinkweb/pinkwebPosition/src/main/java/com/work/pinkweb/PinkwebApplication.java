package com.work.pinkweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PinkwebApplication {

    public static void main(String[] args) {
        SpringApplication.run(PinkwebApplication.class, args);
    }

}
