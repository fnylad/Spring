package com.work.pinkweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PinkwebApplicationTests {

    @Test
    void contextLoads() {
    }

}
