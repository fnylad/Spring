<template>
  <li class="used">
    <div class="used-item">
      <div class="used-top">
        <div class="used-top-left">
          前端开发实习生
        </div>
        <div class="used-top-right">
          15-20K
        </div>
      </div>
      <div class="used-bottom">字节跳动</div>
    </div>
  </li>
</template>

<script>
export default {
  name: "UsedItem"
}
</script>

<style scoped>
@import "../../../assets/css/apply-system/components/useditem.css";
</style>
