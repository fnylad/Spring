<template>
  <el-card shadow="hover" class="message-card project-card">
    <ul class="project">
      <li>
        <span class="project-name">PINK开发</span>
        <span class="project-job">前端开发</span>
        <span class="project-time">2019.10-2020.06</span>
      </li>
      <li>
        <span class="project-address">项目地址：</span>
        <span class="address">https://github.com/Lee8150951/PINK-RecruitmentSystem</span>
      </li>
    </ul>
  </el-card>
</template>

<script>
export default {
  name: "ProjectPanel"
}
</script>

<style scoped>
@import "../../../assets/css/apply-system/components/projectpanel.css";
</style>
