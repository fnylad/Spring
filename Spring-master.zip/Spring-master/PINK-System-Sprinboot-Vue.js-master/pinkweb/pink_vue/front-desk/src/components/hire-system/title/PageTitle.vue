<template>
  <div class="body-title">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: "PageTitle"
}
</script>

<style scoped>
@import "../../../assets/css/hire-system/components/pagetitle.css";
</style>
