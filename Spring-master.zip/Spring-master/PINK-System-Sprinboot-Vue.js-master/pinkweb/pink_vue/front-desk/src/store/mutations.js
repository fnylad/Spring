export default {
  // 侧边栏的展开与收起判定
  contraction(state) {
    state.isCollapse =! state.isCollapse
  }
}
