<template>
  <div>
    <h2>application</h2>
  </div>
</template>

<script>
export default {
  name: "application"
}
</script>

<style scoped>

</style>
