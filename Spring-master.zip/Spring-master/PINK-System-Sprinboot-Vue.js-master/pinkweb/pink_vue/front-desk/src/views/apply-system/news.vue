<template>
  <div>
    <h2>news</h2>
  </div>
</template>

<script>
export default {
  name: "news"
}
</script>

<style scoped>

</style>
