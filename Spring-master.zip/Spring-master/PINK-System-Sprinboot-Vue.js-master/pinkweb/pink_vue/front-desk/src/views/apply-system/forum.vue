<template>
  <div>
    <h2>forum</h2>
  </div>
</template>

<script>
export default {
  name: "forum"
}
</script>

<style scoped>

</style>
