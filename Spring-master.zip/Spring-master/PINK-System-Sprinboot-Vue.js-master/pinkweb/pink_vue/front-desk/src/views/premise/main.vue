<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: "main"
}
</script>

<style scoped>

</style>
