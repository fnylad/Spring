# PINK_WEB

🖖硕士研究生工程实训项目前端架构：Pink招聘系统

本系统分为四大子系统：用户前台子系统、HR管理子系统、公司管理子系统、Admin子系统

前端有manage-system和front-desk两个文件夹，分别在两个文件夹下运行部署：

````shell
npm install
npm run dev
````

后端直接部署即可