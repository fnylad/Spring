<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: "mainView"
}
</script>

<style scoped>

</style>
